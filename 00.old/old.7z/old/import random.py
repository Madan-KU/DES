import random

num = 8 

sampled_num = round(random.expovariate(1.0 / num),0)
print (sampled_num)

numm = 365 * 2

print (str(numm))

rand = random.uniform(0, 1)

print(rand)